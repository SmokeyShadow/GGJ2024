﻿using UnityEngine;
using UnityEditor;
namespace GGJ2024_GiggleTeddy
{
    #region INTERFACES
    public interface IHittable
    {
        void HitReceived();
    }
    #endregion
}